package com.example.oncallnotifier.work

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.oncallnotifier.calendar.GoogleCalendarService
import com.example.oncallnotifier.data.Prefs
import com.example.oncallnotifier.network.TokenRepository
import com.example.oncallnotifier.sheets.SheetsHelper
import com.example.oncallnotifier.util.NotificationHelper
import java.time.LocalDate
import java.time.ZoneId

class WeeklySyncWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    companion object {
        private const val TAG = "WeeklySyncWorker"
        private const val SPREADSHEET_ID =
            "1WNRqwsYg5cVd2066rpE6S169LauvTJMEltDBAd3180Y"
        private const val ML_TITLE = "On Call"
        private const val YL_TITLE = "Yi Ying On Call"
        private val ZONE: ZoneId = ZoneId.of("America/Chicago")

        private val ML_CALENDARS = listOf("mleroy42@gmail.com", "bml6510@gmail.com")
        private val YL_CALENDARS = listOf("by.chanute@gmail.com")

        private const val NOTIFY = true
    }

    override suspend fun doWork(): Result {
        return try {
            val tokenRepo = TokenRepository(applicationContext)
            tokenRepo.refreshIfNeeded()

            val sheets = SheetsHelper(applicationContext, tokenRepo)
            val calendar = GoogleCalendarService(applicationContext, tokenRepo)

            val start = LocalDate.now(ZONE)
            val end = start.plusWeeks(4)

            val a = sheets.readHelperAssignments(SPREADSHEET_ID)
            val mlWindow = a.mlDates.filter { it in start..end }.toSet()
            val ylWindow = a.ylDates.filter { it in start..end }.toSet()

            // Optional: strict cleanup inside the window
            ML_CALENDARS.forEach { calId ->
                calendar.cleanupOnCallBetween(calId, ML_TITLE, mlWindow, start, end)
                calendar.cleanupOnCallBetween(calId, YL_TITLE, emptySet(), start, end)
            }
            YL_CALENDARS.forEach { calId ->
                calendar.cleanupOnCallBetween(calId, YL_TITLE, ylWindow, start, end)
                calendar.cleanupOnCallBetween(calId, ML_TITLE, emptySet(), start, end)
            }

            var created = 0; var deleted = 0
            ML_CALENDARS.forEach { calId ->
                val (c, d) = calendar.reconcileAllDayEvents(
                    dates = mlWindow,
                    summary = ML_TITLE,
                    startDate = start,
                    endDateInclusive = end,
                    attendeesEmails = emptyList(),
                    calendarId = calId
                ); created += c; deleted += d
            }
            YL_CALENDARS.forEach { calId ->
                val (c, d) = calendar.reconcileAllDayEvents(
                    dates = ylWindow,
                    summary = YL_TITLE,
                    startDate = start,
                    endDateInclusive = end,
                    attendeesEmails = emptyList(),
                    calendarId = calId
                ); created += c; deleted += d
            }

            Prefs.setLastSyncOkNow(applicationContext)
            Log.d(TAG, "Weekly sync OK: created=$created, deleted=$deleted")

            if (NOTIFY) {
                NotificationHelper.ensureChannels(applicationContext)
                NotificationHelper.send(
                    context = applicationContext,
                    title = "Weekly sync complete",
                    text = "Created $created, deleted $deleted (window $start..$end)."
                )
            }
            Result.success()
        } catch (t: Throwable) {
            Log.e(TAG, "Weekly sync failed", t)
            if (NOTIFY) {
                NotificationHelper.ensureChannels(applicationContext)
                NotificationHelper.send(
                    context = applicationContext,
                    title = "Weekly sync failed",
                    text = t.message ?: "Unknown error"
                )
            }
            Result.retry()
        }
    }
}
