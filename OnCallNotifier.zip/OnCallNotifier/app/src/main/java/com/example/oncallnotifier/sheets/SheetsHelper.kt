package com.example.oncallnotifier.sheets

import android.content.Context
import com.example.oncallnotifier.network.GoogleApis
import com.example.oncallnotifier.network.TokenRepository
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.floor

data class Assignments(
    val mlDates: Set<LocalDate>,
    val ylDates: Set<LocalDate>
)

/**
 * Reads the OnCallHelper sheet:
 *   Col A = date (ISO string or Google serial)
 *   Col B = "ML" or "YL"
 */
class SheetsHelper(
    private val ctx: Context,
    private val tokenRepo: TokenRepository
) {

    suspend fun readHelperAssignments(spreadsheetId: String): Assignments {
        tokenRepo.refreshIfNeeded()
        val api = GoogleApis.sheets(tokenRepo)

        // Use the explicit method name we defined
        val resp = api.getValues(
            spreadsheetId,
            "OnCallHelper!A2:B",
            "UNFORMATTED_VALUE",
            "ROWS"
        )

        val rows: List<List<Any?>> = resp.values ?: emptyList()

        val ml = linkedSetOf<LocalDate>()
        val yl = linkedSetOf<LocalDate>()

        for (row: List<Any?> in rows) {
            val dRaw: String = row.getOrNull(0)?.toString() ?: continue
            val who: String = row.getOrNull(1)?.toString()?.trim()?.uppercase(Locale.US) ?: continue
            val d: LocalDate = parseSheetDate(dRaw) ?: continue

            when (who) {
                "ML" -> ml.add(d)
                "YL" -> yl.add(d)
            }
        }

        // prefer ML if a date appears in both sets (defensive)
        return Assignments(ml - yl, yl - ml)
    }

    private fun parseSheetDate(cell: String): LocalDate? {
        val s = cell.trim()
        // ISO yyyy-MM-dd
        if (s.matches(Regex("""\d{4}-\d{2}-\d{2}"""))) {
            return runCatching { LocalDate.parse(s, DateTimeFormatter.ISO_LOCAL_DATE) }.getOrNull()
        }
        // US M/d/yyyy
        if (s.matches(Regex("""\d{1,2}/\d{1,2}/\d{4}"""))) {
            val fmt = DateTimeFormatter.ofPattern("M/d/uuuu", Locale.US)
            return runCatching { LocalDate.parse(s, fmt) }.getOrNull()
        }
        // Google Sheets serial (days since 1899-12-30; allow decimals)
        if (s.matches(Regex("""^-?\d+(\.\d+)?$"""))) {
            val serial = s.toDoubleOrNull() ?: return null
            val days = floor(serial).toLong()
            return LocalDate.of(1899, 12, 30).plusDays(days)
        }
        return null
    }
}
