package com.example.oncallnotifier.work

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.oncallnotifier.calendar.GoogleCalendarService
import com.example.oncallnotifier.data.Prefs
import com.example.oncallnotifier.network.TokenRepository
import com.example.oncallnotifier.sheets.SheetsHelper
import java.time.LocalDate
import java.time.ZoneId

class DailySyncWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    companion object {
        private const val TAG = "DailySyncWorker"
        private const val SPREADSHEET_ID =
            "1WNRqwsYg5cVd2066rpE6S169LauvTJMEltDBAd3180Y"
        private const val ML_TITLE = "On Call"
        private const val YL_TITLE = "Yi Ying On Call"
        private val ZONE: ZoneId = ZoneId.of("America/Chicago")

        private val ML_CALENDARS = listOf("mleroy42@gmail.com", "bml6510@gmail.com")
        private val YL_CALENDARS = listOf("by.chanute@gmail.com")
    }

    override suspend fun doWork(): Result {
        return try {
            val tokenRepo = TokenRepository(applicationContext)
            tokenRepo.refreshIfNeeded()

            val sheets = SheetsHelper(applicationContext, tokenRepo)
            val cal = GoogleCalendarService(applicationContext, tokenRepo)

            val start = LocalDate.now(ZONE)
            val end = start.plusWeeks(4)

            val a = sheets.readHelperAssignments(SPREADSHEET_ID)
            val mlWindow = a.mlDates.filter { it in start..end }.toSet()
            val ylWindow = a.ylDates.filter { it in start..end }.toSet()

            ML_CALENDARS.forEach { id ->
                cal.reconcileAllDayEvents(
                    dates = mlWindow,
                    summary = ML_TITLE,
                    startDate = start,
                    endDateInclusive = end,
                    attendeesEmails = emptyList(),
                    calendarId = id
                )
            }
            YL_CALENDARS.forEach { id ->
                cal.reconcileAllDayEvents(
                    dates = ylWindow,
                    summary = YL_TITLE,
                    startDate = start,
                    endDateInclusive = end,
                    attendeesEmails = emptyList(),
                    calendarId = id
                )
            }

            Prefs.setLastSyncOkNow(applicationContext)
            Log.d(TAG, "Daily sync success: ML=${mlWindow.size} YL=${ylWindow.size}")
            Result.success()
        } catch (t: Throwable) {
            Log.e(TAG, "Daily sync failed", t)
            Result.retry()
        }
    }
}
