package com.example.oncallnotifier.network

import okhttp3.Interceptor
import okhttp3.Response

/**
 * Adds Authorization: Bearer <access_token> if we have one.
 */
class AuthInterceptor(
    private val tokenRepo: TokenRepository
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val token = tokenRepo.currentAccessToken()

        val req = if (!token.isNullOrBlank()) {
            original.newBuilder()
                .addHeader("Authorization", "Bearer $token")
                .build()
        } else {
            original
        }
        return chain.proceed(req)
    }
}
