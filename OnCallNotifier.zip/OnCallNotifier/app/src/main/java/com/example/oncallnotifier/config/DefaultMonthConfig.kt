package com.example.oncallnotifier.config

import java.time.LocalDate
import java.time.YearMonth

class DefaultMonthConfig : MonthConfigProvider {

    private val map: MutableMap<YearMonth, MonthRange> = mutableMapOf()

    init {
        putYear(2025, listOf(
            "A1:G7","I1:O7","A9:G16","I9:O16","A18:G24","I18:O24","A26:G32","I26:O33","A35:G41","I35:O41","A43:G50","I43:O50"
        ))
        putYear(2026, listOf(
            "A1:G7","I1:O7","A9:G16","I9:O15","A18:G24","I18:O24","A26:G33","I26:O32","A35:G41","I35:O41","A43:G50","I43:O49"
        ))
        putYear(2027, listOf(
            "A1:G8","I1:O7","A10:G16","I10:O16","A18:G25","I18:O24","A27:G33","I27:O33","A35:G41","I35:O42","A44:G50","I44:O50"
        ))
        putYear(2028, listOf(
            "A1:G8","I1:O7","A10:G16","I10:O17","A19:G25","I19:O25","A27:G34","I27:O33","A36:G42","I36:O42","A44:G50","I44:O51"
        ))
    }

    override fun get(yearMonth: YearMonth): MonthRange? = map[yearMonth]

    private fun putYear(year: Int, rangesJanToDec: List<String>) {
        require(rangesJanToDec.size == 12) { "Need 12 ranges for $year" }
        for (month in 1..12) {
            val ym = YearMonth.of(year, month)
            map[ym] = MonthRange(
                tab = year.toString(),
                rangeA1 = rangesJanToDec[month - 1],
                firstCellDate = sundayStart(ym)
            )
        }
    }

    /**
     * Given a YearMonth, return the Sunday on or before the 1st of that month.
     * (Grid is Sunday-start.)
     */
    private fun sundayStart(ym: YearMonth): LocalDate {
        val first = ym.atDay(1)
        val subtract = first.dayOfWeek.value % 7 // Sunday=7 -> 0, Mon=1 -> 1, ... Sat=6 -> 6
        return first.minusDays(subtract.toLong())
    }
}
