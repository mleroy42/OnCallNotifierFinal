package com.example.oncallnotifier.work

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.ZoneId

/**
 * The ONLY file that declares StartOnBootReceiver.
 * Ensures schedules are set again after device reboot.
 */
class StartOnBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (
            action == Intent.ACTION_BOOT_COMPLETED ||
            action == "android.intent.action.LOCKED_BOOT_COMPLETED"
        ) {
            val zone = ZoneId.of("America/Chicago")
            Scheduler.scheduleDaily(context, zone)
            Scheduler.scheduleWeekly(context, zone)
        }
    }
}
