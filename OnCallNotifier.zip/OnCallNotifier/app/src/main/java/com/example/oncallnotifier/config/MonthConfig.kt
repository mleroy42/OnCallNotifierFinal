package com.example.oncallnotifier.config

import java.time.LocalDate
import java.time.YearMonth

data class MonthRange(
    val tab: String,         // e.g., "2025"
    val rangeA1: String,     // e.g., "A26:G33"
    val firstCellDate: LocalDate // top-left date (Sunday-start grid)
)

interface MonthConfigProvider {
    fun get(yearMonth: YearMonth): MonthRange?
}
