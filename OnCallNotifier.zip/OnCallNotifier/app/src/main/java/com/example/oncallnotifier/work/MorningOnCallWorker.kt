package com.example.oncallnotifier.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.oncallnotifier.network.TokenRepository
import com.example.oncallnotifier.sheets.SheetsHelper
import com.example.oncallnotifier.util.NotificationHelper
import java.time.LocalDate
import java.time.ZoneId

/**
 * Fires at ~06:10 local via Scheduler; shows a notification ONLY on ML (your) days.
 */
class MorningOnCallWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    companion object {
        // Your sheet id; update if needed
        private const val SPREADSHEET_ID =
            "1WNRqwsYg5cVd2066rpE6S169LauvTJMEltDBAd3180Y"
        private val ZONE: ZoneId = ZoneId.of("America/Chicago")
    }

    override suspend fun doWork(): Result {
        return try {
            val tokenRepo = TokenRepository(applicationContext)
            tokenRepo.refreshIfNeeded()

            val sheets = SheetsHelper(applicationContext, tokenRepo)
            val today = LocalDate.now(ZONE)
            val a = sheets.readHelperAssignments(SPREADSHEET_ID) // must expose mlDates

            if (today in a.mlDates) {
                NotificationHelper.ensureChannels(applicationContext)
                NotificationHelper.send(
                    context = applicationContext,
                    title = "On Call Today",
                    text = "You're on call (${today})."
                )
            }
            Result.success()
        } catch (_: Throwable) {
            Result.retry()
        }
    }
}
