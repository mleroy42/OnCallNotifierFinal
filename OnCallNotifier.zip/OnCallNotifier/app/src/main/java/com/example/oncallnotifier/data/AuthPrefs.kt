package com.example.oncallnotifier.data

import android.content.Context
import android.content.SharedPreferences

class AuthPrefs(ctx: Context) {
    private val sp: SharedPreferences =
        ctx.getSharedPreferences("auth_prefs", Context.MODE_PRIVATE)

    var accessToken: String?
        get() = sp.getString("access_token", null)
        set(v) = sp.edit().putString("access_token", v).apply()

    var refreshToken: String?
        get() = sp.getString("refresh_token", null)
        set(v) = sp.edit().putString("refresh_token", v).apply()

    var expiresAtEpochSec: Long
        get() = sp.getLong("expires_at", 0L)
        set(v) = sp.edit().putLong("expires_at", v).apply()
}
