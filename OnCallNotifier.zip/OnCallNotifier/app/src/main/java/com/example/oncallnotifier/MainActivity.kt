package com.example.oncallnotifier

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.oncallnotifier.calendar.GoogleCalendarService
import com.example.oncallnotifier.data.Prefs
import com.example.oncallnotifier.databinding.ActivityMainBinding
import com.example.oncallnotifier.network.TokenRepository
import com.example.oncallnotifier.sheets.SheetsHelper
import com.example.oncallnotifier.work.Scheduler
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.time.LocalDate
import java.time.ZoneId
import java.util.Date

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "MainActivity"

        // === Sheets + Titles ===
        private const val SPREADSHEET_ID =
            "1WNRqwsYg5cVd2066rpE6S169LauvTJMEltDBAd3180Y"
        private const val ML_TITLE = "On Call"
        private const val YL_TITLE = "Yi Ying On Call"
        private val ZONE: ZoneId = ZoneId.of("America/Chicago")

        // === Calendars per label ===
        private val ML_CALENDARS = listOf("mleroy42@gmail.com", "bml6510@gmail.com")
        private val YL_CALENDARS = listOf("by.chanute@gmail.com")

        // One-time strict cleanup inside 4-week window (set false after one successful run)
        private const val CLEAN_WINDOW_STRICT_ONCE = false
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var googleClient: GoogleSignInClient
    private lateinit var tokenRepo: TokenRepository

    // ---------- permissions ----------
    private val requestNotifPerm = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* no-op */ }

    private fun requestNotificationsPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33) {
            val granted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) requestNotifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // ---------- sign-in launcher ----------
    private val signInLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data: Intent? = result.data
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                val account = task.getResult(ApiException::class.java)
                val authCode = account.serverAuthCode
                if (authCode.isNullOrBlank()) {
                    Toast.makeText(this, "No auth code returned", Toast.LENGTH_SHORT).show()
                    return@registerForActivityResult
                }
                lifecycleScope.launch(Dispatchers.IO) {
                    runCatching { tokenRepo.exchangeAuthCode(authCode) }
                        .onSuccess {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(this@MainActivity, "Signed in ✓", Toast.LENGTH_SHORT).show()
                                binding.txtStatus.text = "Signed in"
                                requestNotificationsPermissionIfNeeded()
                                // schedule workers
                                Scheduler.scheduleDaily(this@MainActivity, ZONE)
                                Scheduler.scheduleWeekly(this@MainActivity, ZONE)
                                Scheduler.scheduleMorningAlert(this@MainActivity, ZONE)
                                Scheduler.scheduleNightVolume(this@MainActivity, ZONE)
                            }
                        }
                        .onFailure { e ->
                            Log.e(TAG, "Token exchange failed", e)
                            withContext(Dispatchers.Main) {
                                binding.txtStatus.text = "Sign-in error"
                                Toast.makeText(this@MainActivity, "Token exchange failed: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                }
                // Also schedule at launch if tokens are already valid
                lifecycleScope.launch(Dispatchers.IO) {
                    if (tokenRepo.hasValidTokens()) {
                        withContext(Dispatchers.Main) {
                            requestNotificationsPermissionIfNeeded()
                            Scheduler.scheduleDaily(this@MainActivity, ZONE)
                            Scheduler.scheduleWeekly(this@MainActivity, ZONE)
                            Scheduler.scheduleMorningAlert(this@MainActivity, ZONE)
                            Scheduler.scheduleNightVolume(this@MainActivity, ZONE)
                        }
                    }
                }
            } catch (e: ApiException) {
                Log.e(TAG, "Google sign-in failed", e)
                Toast.makeText(this, "Sign-in failed: ${e.statusCode}", Toast.LENGTH_LONG).show()
                binding.txtStatus.text = "Sign-in failed"
            }
        }

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        tokenRepo = TokenRepository(this)

        val webClientId = getString(R.string.default_web_client_id)
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestServerAuthCode(webClientId, true)
            .requestScopes(
                Scope("https://www.googleapis.com/auth/spreadsheets.readonly"),
                Scope("https://www.googleapis.com/auth/calendar")
            )
            .build()
        googleClient = GoogleSignIn.getClient(this, gso)

        // UI handlers
        binding.btnSignIn.setOnClickListener { beginSignIn() }
        binding.btnManualSync.setOnClickListener { runManualSync() }
        binding.btnSignOut.setOnClickListener { signOut() }

        // night volume slider
        val startPct = Prefs.getNightVolumePercent(this)
        binding.seekNightVolume.progress = startPct
        binding.txtNightVolume.text = "Night volume (21:00): ${startPct}%"
        binding.seekNightVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                binding.txtNightVolume.text = "Night volume (21:00): ${value}%"
                if (fromUser) Prefs.setNightVolumePercent(this@MainActivity, value)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // time pickers
        binding.btnChangeAlertTime.setOnClickListener {
            val (h, m) = Prefs.getAlertTime(this)
            val dlg = android.app.TimePickerDialog(this, { _, hourOfDay, minute ->
                Prefs.setAlertTime(this, hourOfDay, minute)
                Scheduler.scheduleMorningAlert(this, ZONE)
                binding.txtAlertTime.text = "Morning alert: %02d:%02d".format(hourOfDay, minute)
            }, h, m, true)
            dlg.show()
        }
        binding.btnChangeNightTime.setOnClickListener {
            val (h, m) = Prefs.getNightVolumeTime(this)
            val dlg = android.app.TimePickerDialog(this, { _, hourOfDay, minute ->
                Prefs.setNightVolumeTime(this, hourOfDay, minute)
                Scheduler.scheduleNightVolume(this, ZONE)
                binding.txtNightTime.text = "Night volume time: %02d:%02d".format(hourOfDay, minute)
            }, h, m, true)
            dlg.show()
        }

        // initialize time labels & last-sync label
        val (ah, am) = Prefs.getAlertTime(this)
        binding.txtAlertTime.text = "Morning alert: %02d:%02d".format(ah, am)
        val (nh, nm) = Prefs.getNightVolumeTime(this)
        binding.txtNightTime.text = "Night volume time: %02d:%02d".format(nh, nm)
        refreshLastSyncUI()
    }

    // ---------- ui utils ----------
    private fun refreshLastSyncUI() {
        val ts = Prefs.getLastSyncOk(this)
        val label = if (ts == null) {
            "Last successful sync: —"
        } else {
            val df = java.text.DateFormat.getDateTimeInstance(
                java.text.DateFormat.MEDIUM,
                java.text.DateFormat.SHORT
            )
            "Last successful sync: " + df.format(java.util.Date(ts))
        }
        binding.txtLastSynced.text = label
    }

    private fun beginSignIn() = signInLauncher.launch(googleClient.signInIntent)

    private fun signOut() {
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching { googleClient.signOut().await() }
            runCatching { tokenRepo.clear() }
            withContext(Dispatchers.Main) {
                Toast.makeText(this@MainActivity, "Signed out", Toast.LENGTH_SHORT).show()
                binding.txtStatus.text = "Signed out"
            }
        }
    }

    // ---------- manual sync ----------
    private fun runManualSync() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                tokenRepo.refreshIfNeeded()

                val sheets = SheetsHelper(this@MainActivity, tokenRepo)
                val assignments = sheets.readHelperAssignments(SPREADSHEET_ID)

                val start = LocalDate.now(ZONE)
                val end = start.plusWeeks(4)

                val mlWindow = assignments.mlDates.filter { it in start..end }.toSet()
                val ylWindow = assignments.ylDates.filter { it in start..end }.toSet()

                Log.d(TAG, "Window $start..$end | ML=${mlWindow.size} YL=${ylWindow.size}")

                val cal = GoogleCalendarService(this@MainActivity, tokenRepo)

                if (CLEAN_WINDOW_STRICT_ONCE) {
                    ML_CALENDARS.forEach { calId ->
                        cal.cleanupOnCallBetween(calId, ML_TITLE, mlWindow, start, end)
                        cal.cleanupOnCallBetween(calId, YL_TITLE, emptySet(), start, end)
                    }
                    YL_CALENDARS.forEach { calId ->
                        cal.cleanupOnCallBetween(calId, YL_TITLE, ylWindow, start, end)
                        cal.cleanupOnCallBetween(calId, ML_TITLE, emptySet(), start, end)
                    }
                }

                ML_CALENDARS.forEach { calId ->
                    cal.reconcileAllDayEvents(
                        dates = mlWindow,
                        summary = ML_TITLE,
                        startDate = start,
                        endDateInclusive = end,
                        attendeesEmails = emptyList(),
                        calendarId = calId
                    )
                }
                YL_CALENDARS.forEach { calId ->
                    cal.reconcileAllDayEvents(
                        dates = ylWindow,
                        summary = YL_TITLE,
                        startDate = start,
                        endDateInclusive = end,
                        attendeesEmails = emptyList(),
                        calendarId = calId
                    )
                }

                Prefs.setLastSyncOkNow(this@MainActivity)

                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "Sync complete", Toast.LENGTH_SHORT).show()
                    binding.txtStatus.text = "Sync complete"
                    refreshLastSyncUI()
                }
            } catch (t: Throwable) {
                Log.e(TAG, "Manual sync failed", t)
                withContext(Dispatchers.Main) {
                    binding.txtStatus.text = "Sync error"
                    Toast.makeText(this@MainActivity, "Manual sync failed: ${t.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}

// await() helper
private suspend fun <T> com.google.android.gms.tasks.Task<T>.await(): T =
    withContext(kotlinx.coroutines.Dispatchers.IO) {
        kotlinx.coroutines.suspendCancellableCoroutine { cont ->
            addOnSuccessListener { res -> cont.resume(res) {} }
            addOnFailureListener { e -> cont.resumeWith(Result.failure(e)) }
            addOnCanceledListener { cont.cancel() }
        }
    }
