package com.example.oncallnotifier.network

/** Minimal models for Google Calendar v3 we actually use. */

data class CalDate(
    // For all-day events Google uses "date" (YYYY-MM-DD) and end.date is exclusive.
    val date: String? = null,
    // For timed events Google uses "dateTime" RFC3339; we don’t need it, but keep for completeness.
    val dateTime: String? = null,
    // Optional timezone
    val timeZone: String? = null
)

data class CalAttendee(
    val email: String? = null,
    val responseStatus: String? = null
)

data class CalReminders(
    val useDefault: Boolean = false,
    val overrides: List<CalReminder>? = null
)

data class CalReminder(
    val method: String,
    val minutes: Int
)

data class CalEvent(
    val id: String? = null,
    val summary: String? = null,
    val start: CalDate? = null,
    val end: CalDate? = null,
    val attendees: List<CalAttendee>? = null,
    val reminders: CalReminders? = null
)

data class CalEventList(
    val items: List<CalEvent> = emptyList(),
    val nextPageToken: String? = null
)
