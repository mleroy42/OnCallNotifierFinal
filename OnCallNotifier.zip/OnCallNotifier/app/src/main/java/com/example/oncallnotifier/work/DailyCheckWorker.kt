package com.example.oncallnotifier.work

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.time.ZoneId

/**
 * Lightweight worker that (re)schedules our periodic syncs.
 * Replaces the old scheduleDailySync(...) call.
 */
class DailyCheckWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    companion object {
        private const val TAG = "DailyCheckWorker"
        private val ZONE: ZoneId = ZoneId.of("America/Chicago")
    }

    override suspend fun doWork(): Result {
        return try {
            // (Re)schedule the periodic jobs using the new Scheduler API
            Scheduler.scheduleDaily(applicationContext, ZONE)
            Scheduler.scheduleWeekly(applicationContext, ZONE)

            Log.d(TAG, "Rescheduled daily & weekly sync successfully.")
            Result.success()
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to (re)schedule periodic syncs", t)
            Result.retry()
        }
    }
}
