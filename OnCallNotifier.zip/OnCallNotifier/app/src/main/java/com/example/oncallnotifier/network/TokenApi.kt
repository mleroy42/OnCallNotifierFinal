package com.example.oncallnotifier.network

import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

/**
 * Google OAuth token endpoint API.
 * Base URL: https://oauth2.googleapis.com/
 *
 * Use exchangeCode(...) for first-time auth code exchange.
 * Use refresh(...) for refresh_token -> access_token.
 */
interface TokenApi {

    @FormUrlEncoded
    @POST("token")
    suspend fun exchangeCode(
        @Field("code") code: String,
        @Field("client_id") clientId: String,
        @Field("client_secret") clientSecret: String,
        @Field("redirect_uri") redirectUri: String,
        @Field("grant_type") grantType: String = "authorization_code"
    ): TokenResponse

    @FormUrlEncoded
    @POST("token")
    suspend fun refresh(
        @Field("refresh_token") refreshToken: String,
        @Field("client_id") clientId: String,
        @Field("client_secret") clientSecret: String,
        @Field("grant_type") grantType: String = "refresh_token"
    ): TokenResponse
}
