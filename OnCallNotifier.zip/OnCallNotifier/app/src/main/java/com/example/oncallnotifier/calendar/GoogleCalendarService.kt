package com.example.oncallnotifier.calendar

import android.content.Context
import android.util.Log
import com.example.oncallnotifier.network.CalAttendee
import com.example.oncallnotifier.network.CalDate
import com.example.oncallnotifier.network.CalEvent
import com.example.oncallnotifier.network.CalReminders
import com.example.oncallnotifier.network.EventList
import com.example.oncallnotifier.network.GoogleApis
import com.example.oncallnotifier.network.GoogleCalendarApi
import com.example.oncallnotifier.network.TokenRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.min

class GoogleCalendarService(
    private val ctx: Context,
    private val tokenRepo: TokenRepository
) {
    private val tz: ZoneId = ZoneId.of("America/Chicago") // fixed zone
    private val dateFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

    suspend fun reconcileAllDayEvents(
        dates: Set<LocalDate>,
        summary: String,
        startDate: LocalDate,
        endDateInclusive: LocalDate,
        attendeesEmails: List<String>,
        calendarId: String
    ): Pair<Int, Int> = withContext(Dispatchers.IO) {
        tokenRepo.refreshIfNeeded()
        val api = GoogleApis.calendar(tokenRepo)

        // Clamp to window to avoid accidental far-future creates
        val windowDates = dates.filter { it >= startDate && it <= endDateInclusive }.toSet()

        val timeMin = startDate.atStartOfDay(tz).toInstant().toString()
        val timeMax = endDateInclusive.plusDays(1).atStartOfDay(tz).toInstant().toString()

        val existing = try {
            listExisting(api, calendarId, summary, timeMin, timeMax)
        } catch (e: HttpException) {
            logHttp("LIST", calendarId, e)
            throw e
        }

        // Normalize by summary, key only by date after that
        val desiredKeys = windowDates.map { it.format(dateFmt) }.toSet()
        val existingKeys = existing.map { it.startDate }.toSet()

        val toCreate = windowDates.filter { it.format(dateFmt) !in existingKeys }
        val toDelete = existing.filter { it.startDate !in desiredKeys }

        var created = 0
        var deleted = 0

        for (e in toDelete) {
            try {
                Log.d("Calendar", "DELETE cal=$calendarId id=${e.id} ${e.summary} ${e.startDate}")
                api.deleteEvent(calendarId, e.id)
                deleted++
            } catch (ex: HttpException) {
                if (ex.code() == 404) deleted++ else logHttp("DELETE", calendarId, ex, "eventId=${e.id}")
            } catch (t: Throwable) {
                Log.e("Calendar", "Delete crashed cal=$calendarId id=${e.id}", t)
            }
        }

        for (d in toCreate) {
            try {
                Log.d("Calendar", "CREATE cal=$calendarId ${d.format(dateFmt)} $summary")
                val ev = buildAllDayEvent(summary, d, attendeesEmails)
                api.insertEvent(calendarId = calendarId, body = ev)
                created++
            } catch (ex: HttpException) {
                logHttp("INSERT", calendarId, ex, "date=${d.format(dateFmt)} summary=$summary")
            } catch (t: Throwable) {
                Log.e("Calendar", "Insert crashed cal=$calendarId date=$d", t)
            }
        }

        Pair(created, deleted)
    }

    suspend fun cleanupOnCallBetween(
        calendarId: String,
        summary: String,
        keepDates: Set<LocalDate>,
        sweepStart: LocalDate,
        sweepEndInclusive: LocalDate
    ): Int = withContext(Dispatchers.IO) {
        tokenRepo.refreshIfNeeded()
        val api = GoogleApis.calendar(tokenRepo)

        val timeMin = sweepStart.atStartOfDay(tz).toInstant().toString()
        val timeMax = sweepEndInclusive.plusDays(1).atStartOfDay(tz).toInstant().toString()

        val existing = try {
            listExisting(api, calendarId, summary, timeMin, timeMax)
        } catch (e: HttpException) {
            logHttp("LIST", calendarId, e)
            throw e
        }

        val keepKeys = keepDates.map { it.format(dateFmt) }.toSet()
        var deleted = 0
        for (e in existing) {
            if (e.startDate !in keepKeys) {
                try {
                    Log.d("Calendar", "CLEANUP DELETE cal=$calendarId id=${e.id} ${e.summary} ${e.startDate}")
                    api.deleteEvent(calendarId, e.id)
                    deleted++
                } catch (ex: HttpException) {
                    if (ex.code() == 404) deleted++ else logHttp("DELETE", calendarId, ex, "eventId=${e.id}")
                } catch (t: Throwable) {
                    Log.e("Calendar", "Cleanup delete crashed cal=$calendarId id=${e.id}", t)
                }
            }
        }
        deleted
    }

    /**
     * Back-compat single-date upsert.
     */
    suspend fun ensureAllDayEvent(
        date: LocalDate,
        summary: String,
        attendeesEmails: List<String> = emptyList(),
        calendarId: String = "primary"
    ): String = withContext(Dispatchers.IO) {
        tokenRepo.refreshIfNeeded()
        val api = GoogleApis.calendar(tokenRepo)

        val timeMin = date.atStartOfDay(tz).toInstant().toString()
        val timeMax = date.plusDays(1).atStartOfDay(tz).toInstant().toString()

        val existing = try {
            listExisting(api, calendarId, summary, timeMin, timeMax)
        } catch (e: HttpException) {
            logHttp("LIST", calendarId, e)
            throw e
        }

        val match = existing.firstOrNull { it.startDate == date.format(dateFmt) }
        if (match != null) return@withContext "exists:${match.id}"

        return@withContext try {
            val ev = buildAllDayEvent(summary, date, attendeesEmails)
            val created = api.insertEvent(calendarId = calendarId, body = ev)
            "created:${created.id ?: "unknown"}"
        } catch (e: HttpException) {
            logHttp("INSERT", calendarId, e, "date=${date.format(dateFmt)} summary=$summary")
            throw e
        }
    }

    // ---------- internals ----------

    private suspend fun listExisting(
        api: GoogleCalendarApi,
        calendarId: String,
        summary: String,
        timeMin: String,
        timeMax: String
    ): List<RemoteEvent> {
        val targetNorm = normalize(summary)
        val resp: EventList = api.listEvents(
            calendarId = calendarId,
            timeMin = timeMin,
            timeMax = timeMax,
            maxResults = 2500,
            singleEvents = true,
            orderBy = "startTime"
        )
        val items = resp.items.orEmpty()
        val out = mutableListOf<RemoteEvent>()
        for (ev in items) {
            val sum = ev.summary ?: ""
            if (normalize(sum) != targetNorm) continue

            val startDateRaw: String? = ev.start?.date ?: ev.start?.dateTime
            val endDateRaw: String? = ev.end?.date ?: ev.end?.dateTime
            val id = ev.id ?: continue

            val startKey = startDateRaw?.let { it.substring(0, min(10, it.length)) } ?: continue
            val endKey = endDateRaw?.let { it.substring(0, min(10, it.length)) } ?: startKey

            out += RemoteEvent(id = id, summary = sum, startDate = startKey, endRaw = endKey)
        }
        return out
    }

    private fun normalize(s: String): String =
        s.lowercase(Locale.US).replace(Regex("[^a-z0-9]"), "")

    private fun buildAllDayEvent(
        summary: String,
        date: LocalDate,
        attendees: List<String>
    ): CalEvent {
        val start = CalDate(date = date.format(dateFmt), dateTime = null, timeZone = null)
        val end = CalDate(date = date.plusDays(1).format(dateFmt), dateTime = null, timeZone = null)
        val attendeesList: List<CalAttendee>? =
            if (attendees.isNotEmpty()) attendees.map { CalAttendee(email = it, responseStatus = null) } else null
        val reminders = CalReminders(useDefault = false, overrides = null)
        return CalEvent(
            id = null,
            summary = summary,
            start = start,
            end = end,
            attendees = attendeesList,
            reminders = reminders
        )
    }

    private fun logHttp(op: String, calendarId: String, e: HttpException, extra: String? = null) {
        val body = try { e.response()?.errorBody()?.string() } catch (_: Throwable) { null }
        Log.e(
            "Calendar",
            "$op failed cal=$calendarId code=${e.code()} msg=${e.message()}${if (extra != null) " $extra" else ""}\n${body ?: "(no body)"}"
        )
    }

    data class RemoteEvent(
        val id: String,
        val summary: String,
        val startDate: String, // yyyy-MM-dd
        val endRaw: String
    )
}
