package com.example.oncallnotifier.network

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 * Factories for authorized Retrofit APIs (Sheets & Calendar) using the current access token.
 */
object GoogleApis {

    private fun authClient(tokenRepo: TokenRepository): OkHttpClient {
        val auth = AuthInterceptor(tokenRepo)

        return OkHttpClient.Builder()
            .addInterceptor(auth)
            .addInterceptor(
                HttpLoggingInterceptor().apply {
                    level = HttpLoggingInterceptor.Level.BODY
                }
            )
            .build()
    }

    private fun retrofit(baseUrl: String, client: OkHttpClient): Retrofit =
        Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    fun sheets(tokenRepo: TokenRepository): GoogleSheetsAPI =
        retrofit("https://sheets.googleapis.com/", authClient(tokenRepo))
            .create(GoogleSheetsAPI::class.java)

    fun calendar(tokenRepo: TokenRepository): GoogleCalendarApi =
        retrofit("https://www.googleapis.com/calendar/v3/", authClient(tokenRepo))
            .create(GoogleCalendarApi::class.java)
}
