package com.example.oncallnotifier.work

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.oncallnotifier.data.Prefs
import java.time.DayOfWeek
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit
import kotlin.math.max

object Scheduler {

    private const val UNIQUE_DAILY_SYNC   = "daily_sync_work"
    private const val UNIQUE_WEEKLY_SYNC  = "weekly_sync_work"
    private const val UNIQUE_MORNING_ALERT = "morning_oncall_alert"
    private const val UNIQUE_NIGHT_VOLUME  = "night_volume_set"

    /** DailySyncWorker at 06:10 local (unchanged). */
    fun scheduleDaily(context: Context, zone: ZoneId) {
        val first = nextAt(zone, LocalTime.of(6, 10))
        val delayMin = max(0L, Duration.between(Instant.now(), first).toMinutes())
        val req = PeriodicWorkRequestBuilder<DailySyncWorker>(1, TimeUnit.DAYS)
            .setInitialDelay(delayMin, TimeUnit.MINUTES)
            .addTag(UNIQUE_DAILY_SYNC)
            .build()
        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(UNIQUE_DAILY_SYNC, ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    /** WeeklySyncWorker each Sunday 02:00 local (unchanged). */
    fun scheduleWeekly(context: Context, zone: ZoneId) {
        val first = nextDowAt(zone, DayOfWeek.SUNDAY, LocalTime.of(2, 0))
        val delayMin = max(0L, Duration.between(Instant.now(), first).toMinutes())
        val req = PeriodicWorkRequestBuilder<WeeklySyncWorker>(7, TimeUnit.DAYS)
            .setInitialDelay(delayMin, TimeUnit.MINUTES)
            .addTag(UNIQUE_WEEKLY_SYNC)
            .build()
        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(UNIQUE_WEEKLY_SYNC, ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    /** Morning notification at user-picked time (default 06:10) if ML day. */
    fun scheduleMorningAlert(context: Context, zone: ZoneId) {
        val (h, m) = Prefs.getAlertTime(context)
        val first = nextAt(zone, LocalTime.of(h, m))
        val delayMin = max(0L, Duration.between(Instant.now(), first).toMinutes())
        val req = PeriodicWorkRequestBuilder<MorningOnCallWorker>(1, TimeUnit.DAYS)
            .setInitialDelay(delayMin, TimeUnit.MINUTES)
            .addTag(UNIQUE_MORNING_ALERT)
            .build()
        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(UNIQUE_MORNING_ALERT, ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    /** Night volume set at user-picked time (default 21:00) if ML day. */
    fun scheduleNightVolume(context: Context, zone: ZoneId) {
        val (h, m) = Prefs.getNightVolumeTime(context)
        val first = nextAt(zone, LocalTime.of(h, m))
        val delayMin = max(0L, Duration.between(Instant.now(), first).toMinutes())
        val req = PeriodicWorkRequestBuilder<VolumeAtNineWorker>(1, TimeUnit.DAYS)
            .setInitialDelay(delayMin, TimeUnit.MINUTES)
            .addTag(UNIQUE_NIGHT_VOLUME)
            .build()
        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(UNIQUE_NIGHT_VOLUME, ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    // ----- helpers -----

    private fun nextAt(zone: ZoneId, time: LocalTime): Instant {
        val now = ZonedDateTime.now(zone)
        var at = now.with(time)
        if (!at.isAfter(now)) at = at.plusDays(1)
        return at.toInstant()
    }

    private fun nextDowAt(zone: ZoneId, dow: DayOfWeek, time: LocalTime): Instant {
        var z = ZonedDateTime.of(LocalDate.now(zone), time, zone)
        while (z.dayOfWeek != dow || !z.isAfter(ZonedDateTime.now(zone))) {
            z = z.plusDays(1)
        }
        return z.toInstant()
    }
}
