package com.example.oncallnotifier.sync

import android.content.Context
import com.example.oncallnotifier.calendar.GoogleCalendarService
import com.example.oncallnotifier.data.Prefs
import com.example.oncallnotifier.network.TokenRepository
import com.example.oncallnotifier.sheets.SheetsHelper
import java.time.LocalDate
import java.time.ZoneId

class SyncEngine(
    private val context: Context,
    private val tokenRepo: TokenRepository
) {
    companion object {
        private const val SPREADSHEET_ID =
            "1WNRqwsYg5cVd2066rpE6S169LauvTJMEltDBAd3180Y"
        private const val ML_TITLE = "On Call"
        private const val YL_TITLE = "Yi Ying On Call"

        private val ML_CALENDARS = listOf("mleroy42@gmail.com", "bml6510@gmail.com")
        private val YL_CALENDARS = listOf("by.chanute@gmail.com")
    }

    /** Reconciles only the next 4 weeks and records last-success time. */
    suspend fun syncNextFourWeeks(zone: ZoneId) {
        tokenRepo.refreshIfNeeded()

        val sheets = SheetsHelper(context, tokenRepo)
        val cal = GoogleCalendarService(context, tokenRepo)

        val start = LocalDate.now(zone)
        val end = start.plusWeeks(4)

        val a = sheets.readHelperAssignments(SPREADSHEET_ID)
        val mlWindow = a.mlDates.filter { it in start..end }.toSet()
        val ylWindow = a.ylDates.filter { it in start..end }.toSet()

        ML_CALENDARS.forEach { calId ->
            cal.reconcileAllDayEvents(
                dates = mlWindow,
                summary = ML_TITLE,
                startDate = start,
                endDateInclusive = end,
                attendeesEmails = emptyList(),
                calendarId = calId
            )
        }
        YL_CALENDARS.forEach { calId ->
            cal.reconcileAllDayEvents(
                dates = ylWindow,
                summary = YL_TITLE,
                startDate = start,
                endDateInclusive = end,
                attendeesEmails = emptyList(),
                calendarId = calId
            )
        }

        // Mark success for the home screen label
        Prefs.setLastSyncOkNow(context)
    }
}
