package com.example.oncallnotifier.network

import com.google.gson.annotations.SerializedName

/**
 * OAuth token response from Google's token endpoint:
 * https://oauth2.googleapis.com/token
 *
 * Includes helpers for auth header and computing an expiresAt time.
 */
data class TokenResponse(
    @SerializedName("access_token")
    val accessToken: String? = null,

    @SerializedName("expires_in")
    val expiresIn: Long? = null, // seconds

    @SerializedName("refresh_token")
    val refreshToken: String? = null,

    @SerializedName("scope")
    val scope: String? = null,

    @SerializedName("token_type")
    val tokenType: String? = null, // typically "Bearer"

    @SerializedName("id_token")
    val idToken: String? = null,

    // When Google returns an error in a 200 response body (rare)
    @SerializedName("error")
    val error: String? = null,

    @SerializedName("error_description")
    val errorDescription: String? = null
) {
    /** True if the response body itself carries an OAuth error. */
    val isError: Boolean get() = !error.isNullOrBlank()

    /** Standard Authorization header value, e.g. "Bearer ya29...." */
    fun authHeader(): String? =
        if (!accessToken.isNullOrBlank() && !tokenType.isNullOrBlank()) {
            "$tokenType $accessToken"
        } else null

    /**
     * Compute a client-side expiry timestamp in millis.
     * Subtracts a small skew so refresh happens a bit early.
     */
    fun computeExpiresAt(
        nowMillis: Long = System.currentTimeMillis(),
        skewSeconds: Long = 60L
    ): Long? = expiresIn?.let { secs ->
        val safeSecs = if (secs > skewSeconds) secs - skewSeconds else 0L
        nowMillis + safeSecs * 1000L
    }

    /** Convenience: whether we got a usable refresh token back. */
    fun hasRefresh(): Boolean = !refreshToken.isNullOrBlank()
}
