package com.example.oncallnotifier.network

import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Minimal Google Sheets "values" API for reading the OnCallHelper sheet.
 * Base URL should be "https://sheets.googleapis.com/"
 */
interface GoogleSheetsAPI {

    // Primary method name (what SheetsHelper will call)
    @GET("v4/spreadsheets/{id}/values/{range}")
    suspend fun getValues(
        @Path("id") spreadsheetId: String,
        // Encoded so "OnCallHelper!A2:B" passes through safely
        @Path(value = "range", encoded = true) rangeA1: String,
        @Query("valueRenderOption") valueRenderOption: String = "UNFORMATTED_VALUE",
        @Query("majorDimension") majorDimension: String = "ROWS"
    ): ValueRange

    // Alias with a different name in case other code in your project uses it
    @GET("v4/spreadsheets/{id}/values/{range}")
    suspend fun values(
        @Path("id") spreadsheetId: String,
        @Path(value = "range", encoded = true) rangeA1: String,
        @Query("valueRenderOption") valueRenderOption: String = "UNFORMATTED_VALUE",
        @Query("majorDimension") majorDimension: String = "ROWS"
    ): ValueRange
}

/** Minimal model for the "values" response. */
data class ValueRange(
    val range: String? = null,
    val majorDimension: String? = null,
    val values: List<List<Any?>>? = null
)
