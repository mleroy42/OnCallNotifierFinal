package com.example.oncallnotifier.network

import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.POST
import retrofit2.http.Query

/**
 * Response wrapper for Calendar listEvents. Must expose `items`.
 */
data class EventList(
    val items: List<CalEvent>?
)

interface GoogleCalendarApi {

    @GET("calendars/{calendarId}/events")
    suspend fun listEvents(
        // IMPORTANT: do NOT set encoded=true; Retrofit must URL-encode '@'
        @Path("calendarId") calendarId: String,
        @Query("timeMin") timeMin: String,
        @Query("timeMax") timeMax: String,
        @Query("singleEvents") singleEvents: Boolean = true,
        @Query("orderBy") orderBy: String = "startTime",
        @Query("maxResults") maxResults: Int = 2500
    ): EventList

    @POST("calendars/{calendarId}/events")
    suspend fun insertEvent(
        @Path("calendarId") calendarId: String,
        @Body body: CalEvent
    ): CalEvent

    @DELETE("calendars/{calendarId}/events/{eventId}")
    suspend fun deleteEvent(
        @Path("calendarId") calendarId: String,
        @Path("eventId") eventId: String
    )
}
