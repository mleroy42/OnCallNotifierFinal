package com.example.oncallnotifier.network

import android.content.Context
import android.util.Log
import com.example.oncallnotifier.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

/**
 * Handles OAuth token exchange + refresh. Stores tokens in SharedPreferences.
 * Uses empty redirect_uri for auth-code exchange to avoid redirect_uri_mismatch.
 */
class TokenRepository(private val context: Context) {

    companion object {
        private const val TAG = "TokenRepository"
        private const val PREFS = "oauth_tokens"
        private const val KEY_ACCESS = "access_token"
        private const val KEY_REFRESH = "refresh_token"
        private const val KEY_EXPIRES_AT = "expires_at"
    }

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun currentAccessToken(): String? = prefs.getString(KEY_ACCESS, null)

    suspend fun hasValidTokens(): Boolean = withContext(Dispatchers.IO) {
        try {
            refreshIfNeeded()
            true
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Exchange serverAuthCode -> access/refresh tokens.
     * IMPORTANT: redirect_uri is intentionally empty.
     */
    suspend fun exchangeAuthCode(authCode: String) = withContext(Dispatchers.IO) {
        val clientId = context.getString(R.string.default_web_client_id)
        val clientSecret = context.getString(R.string.web_client_secret)

        val form = formUrlEncoded(
            "grant_type" to "authorization_code",
            "code" to authCode,
            "client_id" to clientId,
            "client_secret" to clientSecret,
            "redirect_uri" to "" // <- key to avoid redirect_uri_mismatch
        )

        val json = postForm("https://oauth2.googleapis.com/token", form)
        Log.d(TAG, "exchangeAuthCode response: $json")

        val access = json.optString("access_token", null)
        val refresh = json.optString("refresh_token", null)
        val expiresInSec = json.optLong("expires_in", 0L)

        if (access.isNullOrBlank()) {
            Log.e(TAG, "exchangeAuthCode failed: $json")
            throw IllegalStateException("Auth code exchange failed: HTTP 400")
        }

        val nowMs = System.currentTimeMillis()
        val expiresAtMs = nowMs + TimeUnit.SECONDS.toMillis(expiresInSec.coerceAtLeast(300))

        prefs.edit().putString(KEY_ACCESS, access).apply()
        if (!refresh.isNullOrBlank()) {
            prefs.edit().putString(KEY_REFRESH, refresh).apply()
        }
        prefs.edit().putLong(KEY_EXPIRES_AT, expiresAtMs).apply()
    }

    /**
     * Refresh if no token or token is near expiry (within 60s).
     */
    suspend fun refreshIfNeeded() = withContext(Dispatchers.IO) {
        val access = prefs.getString(KEY_ACCESS, null)
        val refresh = prefs.getString(KEY_REFRESH, null)
        val expiresAtMs = prefs.getLong(KEY_EXPIRES_AT, 0L)
        val nowMs = System.currentTimeMillis()

        // If we still have a valid token, nothing to do
        if (!access.isNullOrBlank() && nowMs < (expiresAtMs - 60_000)) {
            return@withContext
        }

        if (refresh.isNullOrBlank()) {
            throw IllegalStateException("No refresh token")
        }

        val clientId = context.getString(R.string.default_web_client_id)
        val clientSecret = context.getString(R.string.web_client_secret)

        val form = formUrlEncoded(
            "grant_type" to "refresh_token",
            "refresh_token" to refresh,
            "client_id" to clientId,
            "client_secret" to clientSecret
        )

        val json = postForm("https://oauth2.googleapis.com/token", form)
        Log.d(TAG, "refresh response: $json")

        val newAccess = json.optString("access_token", null)
        val expiresInSec = json.optLong("expires_in", 0L)

        if (newAccess.isNullOrBlank()) {
            Log.e(TAG, "refresh failed: $json")
            throw IllegalStateException("Refresh failed")
        }

        val newExpiresAtMs =
            System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(expiresInSec.coerceAtLeast(300))

        prefs.edit()
            .putString(KEY_ACCESS, newAccess)
            .putLong(KEY_EXPIRES_AT, newExpiresAtMs)
            .apply()
        // Google usually doesn't return refresh_token on refresh; keep the old one.
    }

    fun clear() {
        prefs.edit().clear().apply()
    }

    // -------- helpers --------
    private fun formUrlEncoded(vararg pairs: Pair<String, String?>): String {
        fun enc(s: String) = URLEncoder.encode(s, StandardCharsets.UTF_8.name())
        return pairs
            .filter { it.second != null }
            .joinToString("&") { (k, v) -> "${enc(k)}=${enc(v!!)}" }
    }

    private fun postForm(url: String, formBody: String): JSONObject {
        val media = "application/x-www-form-urlencoded".toMediaType()
        val req = Request.Builder()
            .url(url)
            .post(formBody.toRequestBody(media))
            .build()
        val client = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
        client.newCall(req).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                Log.e(TAG, "HTTP ${resp.code} $body")
                throw IllegalStateException("HTTP ${resp.code}")
            }
            return JSONObject(body)
        }
    }
}
