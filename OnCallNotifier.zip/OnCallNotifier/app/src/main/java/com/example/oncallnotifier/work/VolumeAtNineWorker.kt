package com.example.oncallnotifier.work

import android.content.Context
import android.media.AudioManager
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.oncallnotifier.data.Prefs
import com.example.oncallnotifier.network.TokenRepository
import com.example.oncallnotifier.sheets.SheetsHelper
import com.example.oncallnotifier.util.NotificationHelper
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.roundToInt

class VolumeAtNineWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    companion object {
        private const val TAG = "VolumeAtNineWorker"
        private const val SPREADSHEET_ID =
            "1WNRqwsYg5cVd2066rpE6S169LauvTJMEltDBAd3180Y"
        private val ZONE: ZoneId = ZoneId.of("America/Chicago")
    }

    override suspend fun doWork(): Result {
        return try {
            val tokenRepo = TokenRepository(applicationContext)
            tokenRepo.refreshIfNeeded()

            val sheets = SheetsHelper(applicationContext, tokenRepo)
            val today = LocalDate.now(ZONE)
            val a = sheets.readHelperAssignments(SPREADSHEET_ID)

            // Only set volume on ML (your) on-call nights
            if (today in a.mlDates) {
                val pct = Prefs.getNightVolumePercent(applicationContext).coerceIn(0, 100)

                val am = applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                // Ensure ringer is on
                am.ringerMode = AudioManager.RINGER_MODE_NORMAL

                // Compute target ring volume from percentage (at least 1 step so it's never silent)
                val maxRing = am.getStreamMaxVolume(AudioManager.STREAM_RING)
                val targetRing = ((maxRing * pct) / 100.0).roundToInt().coerceIn(1, maxRing)
                am.setStreamVolume(AudioManager.STREAM_RING, targetRing, 0)

                // Optionally align notification stream too (best-effort)
                runCatching {
                    val maxNotif = am.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION)
                    val targetNotif = ((maxNotif * pct) / 100.0).roundToInt().coerceIn(1, maxNotif)
                    am.setStreamVolume(AudioManager.STREAM_NOTIFICATION, targetNotif, 0)
                }

                NotificationHelper.ensureChannels(applicationContext)
                val pctLabel = if (pct >= 100) "max" else "$pct%"
                NotificationHelper.send(
                    context = applicationContext,
                    title = "Volume Set",
                    text = "You’re on call tonight. Ringer set to $pctLabel."
                )
                Log.d(TAG, "Set night volume to $pct% (ring=$targetRing/$maxRing).")
            }

            Result.success()
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to set volume", t)
            Result.retry()
        }
    }
}
