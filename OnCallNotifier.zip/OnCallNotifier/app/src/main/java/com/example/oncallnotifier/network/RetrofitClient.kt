package com.example.oncallnotifier.network

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import com.google.gson.Gson
import com.google.gson.GsonBuilder

/**
 * Centralized Retrofit builders.
 *
 * - oauthRetrofit(): for https://oauth2.googleapis.com/ (TokenApi)
 * - create<T>(retrofit): reified helper to avoid "Not enough information to infer type variable T"
 */
object RetrofitClient {

    // --- Gson ---
    private val gson: Gson by lazy {
        GsonBuilder()
            .serializeNulls()
            .create()
    }

    // --- OkHttp base client with logging (safe to keep at BODY for debugging) ---
    private fun baseClient(): OkHttpClient =
        OkHttpClient.Builder()
            .addInterceptor(
                HttpLoggingInterceptor().apply {
                    // Use BODY while developing; switch to BASIC in production if you prefer
                    level = HttpLoggingInterceptor.Level.BODY
                }
            )
            .build()

    // --- Retrofit for Google OAuth token endpoint ---
    val oauthRetrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl("https://oauth2.googleapis.com/")
            .client(baseClient())
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
    }

    // Expose a ready TokenApi so callers can just use RetrofitClient.tokenApi
    val tokenApi: TokenApi by lazy {
        oauthRetrofit.create(TokenApi::class.java)
    }
}

/**
 * Reified helper to get rid of:
 *  "Not enough information to infer type variable T"
 *
 * Usage:
 *   val api = retrofit.create<GoogleSheetsAPI>()
 */
inline fun <reified T> Retrofit.create(): T = this.create(T::class.java)
