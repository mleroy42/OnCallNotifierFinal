package com.example.oncallnotifier.data

import android.content.Context
import android.content.Context.MODE_PRIVATE

object Prefs {
    private const val FILE = "oncall_prefs"

    private const val KEY_NIGHT_VOLUME_PERCENT = "night_volume_percent"
    private const val KEY_LAST_SYNC_OK = "last_sync_ok_epoch_millis"

    // Time keys (24h)
    private const val KEY_ALERT_HOUR = "alert_hour"       // default 06:10
    private const val KEY_ALERT_MIN  = "alert_min"
    private const val KEY_NIGHT_HOUR = "night_hour"       // default 21:00
    private const val KEY_NIGHT_MIN  = "night_min"

    // ----- Night-volume slider (0..100) -----
    fun getNightVolumePercent(ctx: Context): Int =
        ctx.getSharedPreferences(FILE, MODE_PRIVATE)
            .getInt(KEY_NIGHT_VOLUME_PERCENT, 100)

    fun setNightVolumePercent(ctx: Context, pct: Int) {
        val clamped = pct.coerceIn(0, 100)
        ctx.getSharedPreferences(FILE, MODE_PRIVATE)
            .edit().putInt(KEY_NIGHT_VOLUME_PERCENT, clamped).apply()
    }

    // ----- Last successful sync -----
    fun setLastSyncOkNow(ctx: Context) = setLastSyncOk(ctx, System.currentTimeMillis())

    fun setLastSyncOk(ctx: Context, epochMillis: Long) {
        ctx.getSharedPreferences(FILE, MODE_PRIVATE)
            .edit().putLong(KEY_LAST_SYNC_OK, epochMillis).apply()
    }

    /** Returns null if never synced successfully. */
    fun getLastSyncOk(ctx: Context): Long? {
        val v = ctx.getSharedPreferences(FILE, MODE_PRIVATE)
            .getLong(KEY_LAST_SYNC_OK, -1L)
        return if (v <= 0L) null else v
    }

    // ----- Times (24h) -----
    fun getAlertTime(ctx: Context): Pair<Int, Int> {
        val sp = ctx.getSharedPreferences(FILE, MODE_PRIVATE)
        val h = sp.getInt(KEY_ALERT_HOUR, 6)
        val m = sp.getInt(KEY_ALERT_MIN, 10)
        return h to m
    }

    fun setAlertTime(ctx: Context, hour: Int, minute: Int) {
        ctx.getSharedPreferences(FILE, MODE_PRIVATE)
            .edit()
            .putInt(KEY_ALERT_HOUR, hour)
            .putInt(KEY_ALERT_MIN, minute)
            .apply()
    }

    fun getNightVolumeTime(ctx: Context): Pair<Int, Int> {
        val sp = ctx.getSharedPreferences(FILE, MODE_PRIVATE)
        val h = sp.getInt(KEY_NIGHT_HOUR, 21)
        val m = sp.getInt(KEY_NIGHT_MIN, 0)
        return h to m
    }

    fun setNightVolumeTime(ctx: Context, hour: Int, minute: Int) {
        ctx.getSharedPreferences(FILE, MODE_PRIVATE)
            .edit()
            .putInt(KEY_NIGHT_HOUR, hour)
            .putInt(KEY_NIGHT_MIN, minute)
            .apply()
    }
}
